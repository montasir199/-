import React, { useState, useEffect } from 'react';
import { Shuffle, RotateCcw, Trophy } from 'lucide-react';

type Tile = {
  value: number;
  position: number;
};

function App() {
  const [size, setSize] = useState(3);
  const [tiles, setTiles] = useState<Tile[]>([]);
  const [moves, setMoves] = useState(0);
  const [bestScore, setBestScore] = useState<number | null>(null);
  const [isComplete, setIsComplete] = useState(false);

  const initializePuzzle = () => {
    const numbers = Array.from({ length: size * size - 1 }, (_, i) => i + 1);
    numbers.push(0); // Empty tile
    const shuffled = shuffleArray([...numbers]);
    
    if (!isSolvable(shuffled)) {
      // Make it solvable by swapping last two non-zero elements
      const lastNonZero = shuffled.lastIndexOf(size * size - 1);
      const secondLastNonZero = shuffled.lastIndexOf(size * size - 2);
      [shuffled[lastNonZero], shuffled[secondLastNonZero]] = 
      [shuffled[secondLastNonZero], shuffled[lastNonZero]];
    }

    setTiles(shuffled.map((value, index) => ({ value, position: index })));
    setMoves(0);
    setIsComplete(false);
  };

  const isSolvable = (puzzle: number[]) => {
    let inversions = 0;
    const puzzleWithoutZero = puzzle.filter(num => num !== 0);
    
    for (let i = 0; i < puzzleWithoutZero.length - 1; i++) {
      for (let j = i + 1; j < puzzleWithoutZero.length; j++) {
        if (puzzleWithoutZero[i] > puzzleWithoutZero[j]) {
          inversions++;
        }
      }
    }
    
    return size % 2 === 1 ? inversions % 2 === 0 : inversions % 2 === 1;
  };

  const shuffleArray = (array: number[]) => {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  };

  const moveTile = (index: number) => {
    if (isComplete) return;

    const emptyIndex = tiles.findIndex(tile => tile.value === 0);
    const canMove = isAdjacent(index, emptyIndex);

    if (canMove) {
      const newTiles = [...tiles];
      [newTiles[index], newTiles[emptyIndex]] = [newTiles[emptyIndex], newTiles[index]];
      setTiles(newTiles);
      setMoves(moves + 1);
      
      const isWon = newTiles.every((tile, index) => 
        (index === newTiles.length - 1 && tile.value === 0) || tile.value === index + 1
      );
      
      if (isWon) {
        setIsComplete(true);
        if (!bestScore || moves + 1 < bestScore) {
          setBestScore(moves + 1);
        }
      }
    }
  };

  const isAdjacent = (index1: number, index2: number) => {
    const row1 = Math.floor(index1 / size);
    const col1 = index1 % size;
    const row2 = Math.floor(index2 / size);
    const col2 = index2 % size;
    
    return Math.abs(row1 - row2) + Math.abs(col1 - col2) === 1;
  };

  useEffect(() => {
    initializePuzzle();
  }, [size]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 to-indigo-900 text-white p-8">
      <div className="max-w-lg mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8">لعبة اللغز</h1>
        
        <div className="flex justify-between items-center mb-6">
          <div className="space-y-2">
            <p className="text-lg">الخطوات: {moves}</p>
            {bestScore && <p className="text-lg">أفضل نتيجة: {bestScore}</p>}
          </div>
          
          <div className="space-x-4 rtl:space-x-reverse">
            <button
              onClick={() => setSize(prev => Math.min(prev + 1, 5))}
              className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded"
            >
              زيادة الصعوبة
            </button>
            <button
              onClick={() => setSize(prev => Math.max(prev - 1, 3))}
              className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded"
            >
              تقليل الصعوبة
            </button>
          </div>
        </div>

        <div className="relative">
          <div 
            className="grid gap-2 bg-purple-800/50 p-4 rounded-lg"
            style={{ 
              gridTemplateColumns: `repeat(${size}, 1fr)`,
              aspectRatio: '1/1'
            }}
          >
            {tiles.map((tile, index) => (
              <button
                key={tile.value}
                onClick={() => moveTile(index)}
                className={`
                  ${tile.value === 0 ? 'invisible' : 'bg-white'}
                  aspect-square rounded-lg flex items-center justify-center
                  text-2xl font-bold transition-all duration-200
                  ${tile.value !== 0 ? 'hover:scale-105 text-purple-900' : ''}
                  ${isComplete ? 'cursor-default' : 'cursor-pointer'}
                `}
              >
                {tile.value !== 0 && tile.value}
              </button>
            ))}
          </div>

          {isComplete && (
            <div className="absolute inset-0 bg-black/50 rounded-lg flex items-center justify-center backdrop-blur-sm">
              <div className="text-center">
                <Trophy className="w-16 h-16 mx-auto mb-4 text-yellow-400" />
                <h2 className="text-2xl font-bold mb-4">مبروك! لقد فزت!</h2>
                <p className="mb-4">أكملت اللغز في {moves} خطوة</p>
                <button
                  onClick={initializePuzzle}
                  className="bg-purple-600 hover:bg-purple-700 px-6 py-2 rounded-full flex items-center mx-auto"
                >
                  <RotateCcw className="w-5 h-5 mr-2" />
                  العب مرة أخرى
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 flex justify-center">
          <button
            onClick={initializePuzzle}
            className="bg-purple-600 hover:bg-purple-700 px-6 py-2 rounded-full flex items-center"
          >
            <Shuffle className="w-5 h-5 mr-2" />
            خلط جديد
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;